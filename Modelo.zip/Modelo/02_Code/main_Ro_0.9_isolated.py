# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

#%% Paths

import os

print(os.getcwd())
path= 'C:\\Users\\diego\\Desktop\\DL\\Covid_Guatemala\\Gran_panorama\\Modelo'
os.chdir(path)
print(os.getcwd())

path_input= path+'\\01_Input\\'
path_code= path+'\\02_Code\\'
path_output= path+'\\03_Output\\'

#%% Importing packages

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

import pandas as pd
from datetime import datetime
import numpy as np
import random
import pickle

#%% Parameters

# Transimission rate ro= 2.2, in a group of 5 infected, 4 infected, infect additional 8, and 1 infects 3. 
# resulting probabilities of quantitiy

to_contage_before= np.array([2, 2, 2, 2, 3])
to_contage_after= np.array([1, 1, 1, 1, 1, 1, 1, 1, 1, 0])

# Scenarios
scenarios= 1000

# Total population
total_population= 17915567

# Stopping condition
infected_percentage= 0.90

# Infected ensemble solution
infected_ensemble_solution= []

# Infected Fatality Rate (IFR)
IFR= 0.75/100

# Vaccine parameters
time_for_vaccine= 16 #months Here we select 12 or 16 months.
lead_time_for_vaccine= 3 #months

# Week of the year for introducting shock measures:
instant_shock_measures= 11 # Week of the year

#%% Simulating weeks, each time slot is 1 week
    
# Initial infected
   
infected_ensemble= []
initial_condition= [1]

for k in range(scenarios):
    
    print('Now doing scenario:', k)
    
    infected_run= initial_condition.copy()
    
    i= 0
    
    while len(infected_run) <= (time_for_vaccine+lead_time_for_vaccine)*(52/12):
            
        new_contagions= 0
            
        if len(infected_run) <= instant_shock_measures:
        
            for j in range(infected_run[i]):
                
                new_contagions+= to_contage_before[random.randint(0, len(to_contage_before)-1)]
                
            infected_run.append(new_contagions)
                
            i+= 1

        else:
            
            for j in range(infected_run[i]):
                
                new_contagions+= to_contage_after[random.randint(0, len(to_contage_after)-1)]
                
            infected_run.append(new_contagions)
                
            i+= 1
            
    infected_ensemble.append(infected_run)
   
# Saving work

pandemic_duration= [len(scenario) for scenario in infected_ensemble]

pandemic_duration_average= sum(pandemic_duration)/len(pandemic_duration)

print('Contagion at the middle of the disease (1 week), the pandemic would last in Guatemala: %i months.' % (pandemic_duration_average/4))

#%% Importing real data

url = 'https://covid.ourworldindata.org/data/owid-covid-data.csv'
df = pd.read_csv(url,index_col=0,parse_dates=[0])

guatemala_raw= df[df['location']=='Guatemala']
guatemala_raw['week']= guatemala_raw['date'].apply(lambda x: datetime.strptime(x, '%Y-%m-%d').isocalendar()[1]).astype(int)

weekly_new_cases = pd.pivot_table(guatemala_raw, values='new_cases', index=['week'],\
                    aggfunc=np.sum)

# Letting lists with the same length withing pandemic duration

pandemic_duration_clean= []

for scenario in infected_ensemble:
    
    if len(scenario) < max(pandemic_duration):
        
        for i in range(max(pandemic_duration)-len(scenario)+2):
            scenario.append(np.nan)
            
        pandemic_duration_clean.append(scenario)
        
    else:
        pandemic_duration_clean.append(scenario)

# Making time lists for 1 week transmission and 2 week transmission

time_1_weeks= [min(weekly_new_cases.index)]

i= 0
time_1_weeks= time_1_weeks.copy()
while i < max(pandemic_duration)-1:
    time_1_weeks.append(time_1_weeks[i]+1)
    i+= 1

results_1_w_df= pd.DataFrame({'week':time_1_weeks})

for i in range(len(infected_ensemble)):
    string= 'Scenario'+str(i)
    results_1_w_df['new_cases_predicted_1_weeks_'+string]= infected_ensemble[i]

results_1_w_df= results_1_w_df.set_index('week', drop= True)

#%% Plotting each scenario

# Con 1 semana

step= 4

x_label= []

for element in results_1_w_df.index:
    
    if element <=52:
        x_label.append(str(element)+'-'+'2020')
        
    else:
        x_label.append(str(element-52)+'-'+'2021')

x_label= np.array(x_label)
x_label= x_label[0::step]


fig, ax= plt.subplots()

ax.plot(results_1_w_df.index, results_1_w_df, '-', color='mistyrose', linewidth= 1)
ax.plot(results_1_w_df.index, results_1_w_df.mean(axis= 1), '-', color= 'salmon', linewidth= 0.75)
ax.plot(weekly_new_cases.index, weekly_new_cases['new_cases'], 'o', color= 'royalblue', markersize= 3)

plt.xlabel('Semana-Año', fontsize= 10)
plt.ylabel('Casos nuevos (personas infectadas)', fontsize= 10)

plt.grid(True, which="both", linestyle='--')

plt.xticks(np.arange(min(results_1_w_df.index), max(results_1_w_df.index), step), x_label, rotation= '45',fontsize= 8)
plt.yticks(np.arange(0, max(np.max(results_1_w_df.values),max(weekly_new_cases['new_cases'])), 1500))

plt.annotate("Medidas extremas y \n sostenidas, semana 22 del 2020", xy=(22, 5700), \
             xytext=(31, 5700), arrowprops=dict(arrowstyle="->"), color= 'black')

plt.annotate('', xy=(11, 7500), xycoords='data', xytext=(23, 7500), textcoords='data', arrowprops={'arrowstyle': '<->'})
plt.annotate('Ro = 2.2', xy=(13, 7800), xycoords='data', xytext=(-2, 0), textcoords='offset points')

plt.annotate('', xy=(23, 7500), xycoords='data', xytext=(max(results_1_w_df.index), 7500), textcoords='data', arrowprops={'arrowstyle': '<->'})
plt.annotate('Ro = 0.9', xy=(50, 7800), xycoords='data', xytext=(-2, 0), textcoords='offset points')

misty_patch = mpatches.Patch(color='mistyrose', label='Realizaciones - '+str(scenarios)+' escenarios')
salmon_patch = mpatches.Patch(color= 'salmon', label='Realizaciones promedio')
blue_patch = mpatches.Patch(color= 'royalblue', label='Reportados-¿real?')
plt.legend(handles=[misty_patch, salmon_patch, blue_patch], loc= 0, frameon= False)
plt.title('Casos nuevos 1 semana, Ro= 2.2, Ro=0.9 y vacuna='+str(time_for_vaccine)+'meses')

plt.tight_layout()
plt.savefig(path_output+'naive_model_1_weeks_Ro_0.9_'+str(time_for_vaccine)+'mv.jpg', dpi= 1200)
plt.show()

print('The average number of deaths equals: ', int(np.sum(results_1_w_df.values)/scenarios*IFR))
print('The average percent of population infected: ', round(np.sum(results_1_w_df.values)/scenarios/total_population*100, 2))

pickle.dump(infected_ensemble, open(path_output+"Ro_0.9_isolated_ensemble"+str(time_for_vaccine)+".p", "wb"))

