
main_Ro_2.2_free.py >> Python file with the models of evolution of pandemic between week 11 and 23 of the year 2020. It also calculates the entire duration of a pandemic
without control.

main_Ro_0.9_isolated.py >> Python file with the models of evolution if the pandemic is drastically controlled after week 23 of the year 2020.

Calculations_20200522.x.sx >> Excel file, with the PIB/capita calulations
