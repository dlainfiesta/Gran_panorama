+-- Modelo

¦   +-- 01_Input

¦   +-- 02_Code
	¦   +-- main_Ro_2.2_free.py 		>> 	Python file simulates the duration of the epidemic if it were to be let run free in Guatemala, until 90% of the population is 
							infected. It also calculates the estimated amount of fatalities.

	¦   +-- main_Ro_0.9_isolated.py 	>> 	Python file with the models of evolution if the pandemic is drastically controlled after week 23 of the year 2020.

	¦   +-- Calculations_20200522.xlsx 	>> 	Excel file, with the PIB/capita calulations.


¦   +-- 03_Output				>>	Various graphs, resulting from 2_Code.













